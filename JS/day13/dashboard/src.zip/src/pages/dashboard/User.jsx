const Users = () => <h1 className="text-2xl font-bold">Users Page</h1>;
export default Users;
